var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// backend/src/functions/subscribers/list.ts
var list_exports = {};
__export(list_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(list_exports);
var import_lib_dynamodb2 = require("@aws-sdk/lib-dynamodb");

// backend/src/lib/dynamodb.ts
var import_client_dynamodb = require("@aws-sdk/client-dynamodb");
var import_lib_dynamodb = require("@aws-sdk/lib-dynamodb");
var client = new import_client_dynamodb.DynamoDBClient({});
var dynamodb = import_lib_dynamodb.DynamoDBDocumentClient.from(client);

// backend/src/lib/utils.ts
function createResponse(statusCode, body) {
  return {
    statusCode,
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "Content-Type",
      "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS"
    },
    body: JSON.stringify(body)
  };
}

// backend/src/functions/subscribers/list.ts
var TABLE_NAME = process.env.TABLE_NAME;
async function handler(event) {
  try {
    const waitlistId = event.queryStringParameters?.waitlistId;
    const limit = parseInt(event.queryStringParameters?.limit || "100");
    const lastKey = event.queryStringParameters?.lastKey;
    const sortOrder = event.queryStringParameters?.sortOrder || "desc";
    const search = event.queryStringParameters?.search;
    let result;
    if (waitlistId) {
      const queryParams = {
        TableName: TABLE_NAME,
        IndexName: "GSI1",
        KeyConditionExpression: "GSI1PK = :pk AND begins_with(GSI1SK, :sk)",
        ExpressionAttributeValues: {
          ":pk": `WAITLIST#${waitlistId}`,
          ":sk": "SUBSCRIBER#"
        },
        Limit: limit,
        ScanIndexForward: sortOrder === "asc"
      };
      if (search) {
        queryParams.FilterExpression = "contains(email, :search)";
        queryParams.ExpressionAttributeValues[":search"] = search;
      }
      if (lastKey) {
        queryParams.ExclusiveStartKey = JSON.parse(decodeURIComponent(lastKey));
      }
      result = await dynamodb.send(new import_lib_dynamodb2.QueryCommand(queryParams));
    } else {
      const scanParams = {
        TableName: TABLE_NAME,
        FilterExpression: "begins_with(PK, :pk)",
        ExpressionAttributeValues: {
          ":pk": "SUBSCRIBER#"
        },
        Limit: limit
      };
      if (search) {
        scanParams.FilterExpression += " AND contains(email, :search)";
        scanParams.ExpressionAttributeValues[":search"] = search;
      }
      if (lastKey) {
        scanParams.ExclusiveStartKey = JSON.parse(decodeURIComponent(lastKey));
      }
      result = await dynamodb.send(new import_lib_dynamodb2.ScanCommand(scanParams));
    }
    const subscribers = result.Items?.map((item) => ({
      subscriberId: item.subscriberId,
      email: item.email,
      waitlistId: item.waitlistId,
      createdAt: item.createdAt
    })) || [];
    return createResponse(200, {
      subscribers,
      lastKey: result.LastEvaluatedKey ? encodeURIComponent(JSON.stringify(result.LastEvaluatedKey)) : null,
      count: subscribers.length
    });
  } catch (error) {
    console.error("Error listing subscribers:", error);
    return createResponse(500, { error: "Internal server error" });
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
